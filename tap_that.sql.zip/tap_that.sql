-- phpMyAdmin SQL Dump
-- version 4.4.10
-- http://www.phpmyadmin.net
--
-- Host: localhost:3306
-- Generation Time: Sep 04, 2015 at 07:45 AM
-- Server version: 5.5.42
-- PHP Version: 5.6.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `tap_that`
--
CREATE DATABASE IF NOT EXISTS `tap_that` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `tap_that`;

-- --------------------------------------------------------

--
-- Table structure for table `beers`
--

CREATE TABLE `beers` (
  `id` int(11) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `type` varchar(255) DEFAULT NULL,
  `abv` decimal(3,1) DEFAULT NULL,
  `region` varchar(255) DEFAULT NULL,
  `ibu` int(10) DEFAULT NULL,
  `brewery_id` int(11) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=74 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `beers`
--

INSERT INTO `beers` (`id`, `name`, `type`, `abv`, `region`, `ibu`, `brewery_id`) VALUES
(3, 'Replay IPA', 'IPA', '4.5', 'Portland', 40, 1),
(4, 'Upheaval IPA', 'IPA', '7.0', 'Portland', 85, 1),
(5, 'Drop Top Amber Ale', 'Amber', '5.3', 'Portland', 18, 1),
(6, 'Alchemy Pale Ale', 'Pale Ale', '5.8', 'Portland', 40, 1),
(7, 'Steel Bridge Porter', 'Porter', '5.6', 'Portland', 48, 1),
(8, 'KGB Russian Imperial Stout', 'Stout', '9.3', 'Portland', 70, 1),
(9, 'Saison A Fleurs', 'Saison', '6.7', 'Portland', 25, 1),
(10, 'BRRR Seasonal Ale', 'Seasonal', '7.2', 'Portland', 50, 1),
(11, 'Dead Guy Ale', 'German Maibock', '6.5', 'Newport', 40, 2),
(12, 'Chocolate Stout', 'Stout', '5.8', 'Newport', 69, 2),
(13, 'Mocha Porter', 'Porter', '5.3', 'Newport', 54, 2),
(14, 'Juniper Pale Ale', 'Pale Ale', '5.3', 'Newport', 29, 2),
(15, 'Honey Kolsch', 'Kolsch', '5.0', 'Newport', 26, 2),
(16, 'Pumpkin Patch Ale', 'Seasonal', '6.1', 'Newport', 25, 2),
(17, 'Yellow Snow IPA', 'IPA', '6.5', 'Newport', 82, 2),
(18, 'Chipotle Ale', 'Amber', '5.4', 'Newport', 40, 2),
(19, 'Irish Lager', 'Lager', '4.6', 'Newport', 28, 2),
(20, 'Sriracha Hot Stout', 'Stout', '5.7', 'Newport', 55, 2),
(21, 'Vortex IPA', 'IPA', '7.7', 'Astoria', 97, 3),
(22, 'Jai Alai IPA', 'IPA', '7.5', 'Astoria', 70, 3),
(23, 'Hellcat Peppered Tripel', 'Tripel', '8.2', 'Astoria', 81, 3),
(24, 'Secret Saison', 'Saison', '5.5', 'Astoria', 40, 3),
(25, 'It''s A Trap', 'Belgain Pale Ale', '5.6', 'Astoria', 40, 3),
(26, 'Drunkin Pumpkin', 'Seasonal', '6.5', 'Astoria', 25, 3),
(27, 'Vertigo Effect', 'Pale Ale', '4.7', 'Astoria', 28, 3),
(28, 'Fresh IPA', 'IPA', '6.4', 'Astoria', 72, 3),
(29, 'North VIII', 'Russian Imperial Stout', '9.9', 'Astoria', 50, 3),
(30, 'Vladimir Gluten', 'Baltic Porter', '8.5', 'Astoria', 60, 3),
(31, 'Off Leash', 'Session Ale', '4.5', 'Bend', 30, 4),
(32, 'Impasse', 'Saison', '6.6', 'Bend', 25, 4),
(33, 'Outcast', 'IPA', '8.0', 'Bend', 60, 4),
(34, 'Half Hitch', 'Imperial Mosaic IPA', '10.0', 'Bend', 80, 4),
(35, 'Better Off Red', 'Red Ale', '7.0', 'Bend', 18, 4),
(36, 'Doublecross', 'Belgian', '11.0', 'Bend', 20, 4),
(37, 'Freakcake', 'Oud Bruin', '10.5', 'Bend', 35, 4),
(38, 'Tough Love', 'Imperial Stout', '11.5', 'Bend', 70, 4),
(39, 'Crux Pale', 'Pale Ale', '5.0', 'Bend', 35, 4),
(40, 'On The Nitro Fence', 'Pale Ale', '6.4', 'Bend', 50, 4),
(41, 'Apocalypse IPA', 'IPA', '6.8', 'Bend', 70, 5),
(42, 'S1nist0r Black', 'Schwarzbier', '5.4', 'Bend', 38, 5),
(43, 'Joe IPA', 'IPA', '6.8', 'Bend', 70, 5),
(44, 'Swill', 'Radler', '4.5', 'Bend', 4, 5),
(45, 'RPM IPA', 'IPA', '6.5', 'Bend', 50, 6),
(46, 'Hop Venom', 'IPA', '9.0', 'Bend', 60, 6),
(47, 'Norotious', 'Amber', '11.5', 'Bend', 80, 6),
(48, 'Diablo Rojo', 'Red', '5.5', 'Bend', 30, 6),
(49, 'Suge Knite', 'Imperial Stout', '13.0', 'Bend', 80, 6),
(50, 'Armored Fist', 'Cascadian Dark Ale', '10.0', 'Bend', 80, 6),
(51, 'Bone Light', 'India Session Ale', '4.0', 'Bend', 20, 6),
(52, 'Backbone', 'Stout', '6.0', 'Bend', 20, 6),
(53, 'Bone-A-Fide', 'Pale Ale', '5.5', 'Bend', 38, 6),
(54, 'Femme Fatale', 'Sour Ale', '6.5', 'Bend', 15, 6),
(55, 'Wit Shack', 'Belgain Style White Ale', '5.0', 'Bend', 10, 6),
(56, 'Montucky Cold Snack', 'American Pale Lager', '4.0', 'Wisconsin', 21, 7),
(57, 'Rainier Ale', 'Lager', '4.6', 'California', 21, 7),
(58, 'Pabst', 'Lager', '4.0', 'California', 21, 7),
(59, 'Natural Light', 'Lager', '4.2', 'Missouri', 21, 7),
(60, 'Colt 45', 'Malt Liquor', '5.6', 'California', 21, 7),
(61, 'Mickeys', 'Malt Liquor', '5.6', 'Wisconsin', 21, 7),
(62, 'Old German ', 'Lager', '4.2', 'Pennsylvania', 21, 7),
(63, 'Yuengling', 'Lager', '4.4', 'Pennsylvania', 21, 7),
(64, 'Lone Star Beer', 'Lager', '5.6', 'California', 21, 7),
(65, 'Hoppyum', 'IPA', '6.2', 'North Carolina', 70, 8),
(66, 'Jade IPA', 'IPA', '7.4', 'North Carolina', 86, 8),
(67, 'Pilot Mountain Pale Ale', 'Pale Ale', '5.5', 'North Carolina', 52, 8),
(68, 'Torch Pilsner', 'Pilner', '5.3', 'North Carolina', 35, 8),
(69, 'People''s Porter', 'Porter', '5.8', 'North Carolina', 39, 8),
(70, 'Foothills Oktoberfest', 'Seasonal', '6.3', 'North Carolina', 29, 8),
(71, 'Sexual Chocolate', 'Imperial Stout', '9.8', 'North Carolina', 85, 8),
(72, 'Gruffmeister Maibock', 'Maibock', '8.0', 'North Carolina', 30, 8),
(73, 'Baltic Porter', 'Porter', '9.0', 'North Carolina', 52, 8);

-- --------------------------------------------------------

--
-- Table structure for table `breweries`
--

CREATE TABLE `breweries` (
  `id` int(11) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `location` varchar(255) DEFAULT NULL,
  `link` varchar(255) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `breweries`
--

INSERT INTO `breweries` (`id`, `name`, `location`, `link`) VALUES
(1, 'Widmer Brothers Brewing', '929 N Russell St, Portland, OR 97227', 'www.widmerbrothers.com/'),
(2, 'Rogue Ales & Spirits', '1339 NW Flanders St, Portland, OR 97209', 'www.rogue.com/'),
(3, 'Fort George Brewery', '1483 Duane St, Astoria, OR 97103', 'www.fortgeorgebrewery.com/'),
(4, 'Crux Fermentation Project', '50 SW Division St, Bend, OR 97702', 'www.cruxfermentation.com/'),
(5, '10 Barrel Brewing', '1411 NW Flanders St, Portland, OR 97232', 'www.10barrel.com/\r\n'),
(6, 'Boneyard Brewery', '37 NW Lake Pl # B, Bend, OR 97701', 'www.boneyardbeer.com/'),
(7, 'Domestic Brewing Co.', 'USA', 'www.beer.com'),
(8, 'Foothills Brewing', '3800 Kimwell Dr.\r\nWinston-Salem, NC 27103', 'www.foothillsbrewing.com/\r\n');

-- --------------------------------------------------------

--
-- Table structure for table `brews`
--

CREATE TABLE `brews` (
  `beer_id` int(11) NOT NULL,
  `drunk_id` int(11) NOT NULL,
  `id` int(11) NOT NULL,
  `pub_id` int(11) DEFAULT NULL,
  `beer_rating` decimal(3,1) DEFAULT NULL,
  `brew_date` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `drunks`
--

CREATE TABLE `drunks` (
  `id` bigint(20) unsigned NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `date_of_birth` date DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `location` varchar(255) DEFAULT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `on_tap`
--

CREATE TABLE `on_tap` (
  `id` int(11) NOT NULL,
  `pub_id` int(11) DEFAULT NULL,
  `beer_id` int(11) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=112 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `on_tap`
--

INSERT INTO `on_tap` (`id`, `pub_id`, `beer_id`) VALUES
(2, 2, 45),
(3, 2, 24),
(4, 2, 56),
(5, 2, 71),
(6, 2, 33),
(7, 10, 64),
(8, 10, 43),
(9, 10, 32),
(10, 10, 10),
(11, 10, 23),
(12, 10, 55),
(13, 10, 70),
(14, 10, 44),
(15, 10, 46),
(16, 10, 66),
(17, 11, 3),
(18, 11, 4),
(19, 11, 14),
(20, 11, 22),
(21, 11, 56),
(22, 11, 45),
(23, 11, 70),
(24, 11, 65),
(25, 11, 43),
(26, 11, 42),
(27, 12, 3),
(28, 12, 4),
(29, 12, 43),
(30, 12, 12),
(31, 12, 11),
(32, 13, 13),
(33, 13, 5),
(34, 13, 53),
(35, 13, 66),
(36, 13, 70),
(37, 14, 3),
(38, 14, 15),
(39, 14, 14),
(40, 14, 54),
(41, 14, 35),
(42, 15, 3),
(43, 15, 15),
(44, 15, 17),
(45, 15, 63),
(46, 14, 53),
(47, 16, 3),
(48, 16, 4),
(49, 16, 16),
(50, 16, 61),
(51, 16, 72),
(52, 16, 53),
(53, 16, 7),
(54, 16, 50),
(55, 16, 10),
(56, 16, 11),
(57, 17, 17),
(58, 17, 4),
(59, 17, 18),
(60, 17, 27),
(61, 17, 25),
(62, 18, 18),
(63, 18, 19),
(64, 18, 3),
(65, 18, 56),
(66, 18, 34),
(67, 19, 19),
(68, 19, 3),
(69, 19, 20),
(70, 19, 8),
(71, 19, 9),
(72, 20, 20),
(73, 20, 69),
(74, 20, 68),
(75, 20, 27),
(76, 20, 66),
(77, 21, 21),
(78, 21, 22),
(79, 21, 23),
(80, 21, 3),
(81, 21, 43),
(82, 21, 44),
(83, 21, 45),
(84, 21, 47),
(85, 21, 55),
(86, 21, 66),
(87, 22, 22),
(88, 22, 3),
(89, 22, 16),
(90, 22, 6),
(91, 22, 19),
(92, 23, 23),
(93, 23, 3),
(94, 23, 7),
(95, 23, 72),
(96, 23, 73),
(97, 24, 24),
(98, 24, 4),
(99, 24, 73),
(100, 24, 55),
(101, 24, 61),
(102, 25, 3),
(103, 25, 4),
(104, 25, 70),
(105, 25, 25),
(106, 25, 7),
(107, 25, 19),
(108, 25, 69),
(109, 25, 52),
(110, 25, 47),
(111, 25, 48);

-- --------------------------------------------------------

--
-- Table structure for table `pubs`
--

CREATE TABLE `pubs` (
  `id` int(11) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `location` varchar(255) DEFAULT NULL,
  `link` varchar(255) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `pubs`
--

INSERT INTO `pubs` (`id`, `name`, `location`, `link`) VALUES
(2, 'The Slammer Tavern', '500 SE 8th Ave, Portland, OR 97214', 'http://pdxbars.com/slammer'),
(10, 'Marathon Taverna', '1735 W Burnside St Portland, OR 97209‎', 'http://marathontaverna.com/'),
(11, 'Apex Bar PDX', '1216 SE Division St, Portland, OR 97202', 'www.apex.com'),
(12, 'Green Dragon Bistro and Pub', '928 SE 9th Ave, Portland, OR 97214', 'pdxgreendragon.com/'),
(13, 'The Side Street Tavern', '828 SE 34th Ave Portland, OR 97214', 'http://www.sidestreetpdx.com/'),
(14, 'Watertrough Saloon', '4815 SE Hawthorne Blvd Portland, OR 97215', 'http://www.notfortourists.com/LD.aspx/Portland/Nightlife/Water-Trough-Saloon'),
(15, 'Bar Bar', '3939 N Mississippi Ave, Portland, OR 97227', 'www.mississippistudios.com/bar-bar/'),
(16, 'Triple Nickel Pub', '3646 SE Belmont St, Portland, OR 97214', 'www.triplenickel.org/'),
(17, 'Back Stage Bar', '3702 SE Hawthorne Blvd, Portland, OR 97214', 'www.mcmenamins.com/223-back-stage-bar-event-overview'),
(18, 'Horse Brass Pub', '4534 SE Belmont St, Portland, OR 97215', 'www.horsebrass.com/'),
(19, 'Clinton Street Pub', '2516 SE Clinton St, Portland, OR 97202', 'pdxbars.com/clinton-street-pub'),
(20, 'Night Light Lounge', '2100 SE Clinton St, Portland, OR 97202', 'www.nightlightlounge.net/'),
(21, 'Space Room Lounge', '4800 SE Hawthorne Blvd, Portland, OR 97215', 'www.spaceroomlounge.com/'),
(22, 'Rose & Thistle Public Houst', '2314 NE Broadway St, Portland, OR 97232', 'www.roseandthistlepdx.com/'),
(23, 'The Standard', '14 NE 22nd Ave, Portland, OR 97232', 'https://www.standard.com/'),
(24, 'Blitz Ladd', '2239 SE 11th Ave Portland, OR', 'http://www.blitzladd.com/'),
(25, 'Limelight Restaurant & Lounge', ' 6708 SE Milwaukie Ave, Portland, OR 97202', 'http://www.yelp.com/biz/limelight-restaurant-and-lounge-portland');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `beers`
--
ALTER TABLE `beers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `breweries`
--
ALTER TABLE `breweries`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `brews`
--
ALTER TABLE `brews`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `drunks`
--
ALTER TABLE `drunks`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `on_tap`
--
ALTER TABLE `on_tap`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pubs`
--
ALTER TABLE `pubs`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `beers`
--
ALTER TABLE `beers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=74;
--
-- AUTO_INCREMENT for table `breweries`
--
ALTER TABLE `breweries`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `brews`
--
ALTER TABLE `brews`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `drunks`
--
ALTER TABLE `drunks`
  MODIFY `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `on_tap`
--
ALTER TABLE `on_tap`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=112;
--
-- AUTO_INCREMENT for table `pubs`
--
ALTER TABLE `pubs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=27;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
