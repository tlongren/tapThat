-- phpMyAdmin SQL Dump
-- version 4.4.11
-- http://www.phpmyadmin.net
--
-- Host: localhost:8080
-- Generation Time: Sep 02, 2015 at 11:53 PM
-- Server version: 5.6.26
-- PHP Version: 5.6.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `tap_that`
--
CREATE DATABASE IF NOT EXISTS `tap_that` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `tap_that`;

-- --------------------------------------------------------

--
-- Table structure for table `beers`
--

CREATE TABLE IF NOT EXISTS `beers` (
  `id` int(11) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `type` varchar(255) DEFAULT NULL,
  `abv` decimal(3,1) DEFAULT NULL,
  `region` varchar(255) DEFAULT NULL,
  `ibu` int(10) DEFAULT NULL,
  `brewery_id` int(11) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=45 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `beers`
--

INSERT INTO `beers` (`id`, `name`, `type`, `abv`, `region`, `ibu`, `brewery_id`) VALUES
(3, 'Replay IPA', 'IPA', '4.5', 'Portland', 40, 1),
(4, 'Upheaval IPA', 'IPA', '7.0', 'Portland', 85, 1),
(5, 'Drop Top Amber Ale', 'Amber', '5.3', 'Portland', 18, 1),
(6, 'Alchemy Pale Ale', 'Pale Ale', '5.8', 'Portland', 40, 1),
(7, 'Steel Bridge Porter', 'Porter', '5.6', 'Portland', 48, 1),
(8, 'KGB Russian Imperial Stout', 'Stout', '9.3', 'Portland', 70, 1),
(9, 'Saison A Fleurs', 'Saison', '6.7', 'Portland', 25, 1),
(10, 'BRRR Seasonal Ale', 'Seasonal', '7.2', 'Portland', 50, 1),
(11, 'Dead Guy Ale', 'German Maibock', '6.5', 'Newport', 40, 2),
(12, 'Chocolate Stout', 'Stout', '5.8', 'Newport', 69, 2),
(13, 'Mocha Porter', 'Porter', '5.3', 'Newport', 54, 2),
(14, 'Juniper Pale Ale', 'Pale Ale', '5.3', 'Newport', 29, 2),
(15, 'Honey Kolsch', 'Kolsch', '5.0', 'Newport', 26, 2),
(16, 'Pumpkin Patch Ale', 'Seasonal', '6.1', 'Newport', 25, 2),
(17, 'Yellow Snow IPA', 'IPA', '6.5', 'Newport', 82, 2),
(18, 'Chipotle Ale', 'Amber', '5.4', 'Newport', 40, 2),
(19, 'Irish Lager', 'Lager', '4.6', 'Newport', 28, 2),
(20, 'Sriracha Hot Stout', 'Stout', '5.7', 'Newport', 55, 2),
(21, 'Vortex IPA', 'IPA', '7.7', 'Astoria', 97, 3),
(22, 'Jai Alai IPA', 'IPA', '7.5', 'Astoria', 70, 3),
(23, 'Hellcat Peppered Tripel', 'Tripel', '8.2', 'Astoria', 81, 3),
(24, 'Secret Saison', 'Saison', '5.5', 'Astoria', 40, 3),
(25, 'It''s A Trap', 'Belgain Pale Ale', '5.6', 'Astoria', 40, 3),
(26, 'Drunkin Pumpkin', 'Seasonal', '6.5', 'Astoria', 25, 3),
(27, 'Vertigo Effect', 'Pale Ale', '4.7', 'Astoria', 28, 3),
(28, 'Fresh IPA', 'IPA', '6.4', 'Astoria', 72, 3),
(29, 'North VIII', 'Russian Imperial Stout', '9.9', 'Astoria', 50, 3),
(30, 'Vladimir Gluten', 'Baltic Porter', '8.5', 'Astoria', 60, 3),
(31, 'Off Leash', 'Session Ale', '4.5', 'Bend', 30, 4),
(32, 'Impasse', 'Saison', '6.6', 'Bend', 25, 4),
(33, 'Outcast', 'IPA', '8.0', 'Bend', 60, 4),
(34, 'Half Hitch', 'Imperial Mosaic IPA', '10.0', 'Bend', 80, 4),
(35, 'Better Off Red', 'Red Ale', '7.0', 'Bend', 18, 4),
(36, 'Doublecross', 'Belgian', '11.0', 'Bend', 20, 4),
(37, 'Freakcake', 'Oud Bruin', '10.5', 'Bend', 35, 4),
(38, 'Tough Love', 'Imperial Stout', '11.5', 'Bend', 70, 4),
(39, 'Crux Pale', 'Pale Ale', '5.0', 'Bend', 35, 4),
(40, 'On The Nitro Fence', 'Pale Ale', '6.4', 'Bend', 50, 4),
(41, 'Apocalypse IPA', 'IPA', '6.8', 'Bend', 70, 5),
(42, 'S1nist0r Black', 'Schwarzbier', '5.4', 'Bend', 38, 5),
(43, 'Joe IPA', 'IPA', '6.8', 'Bend', 70, 5),
(44, 'Swill', 'Radler', '4.5', 'Bend', 4, 5);

-- --------------------------------------------------------

--
-- Table structure for table `breweries`
--

CREATE TABLE IF NOT EXISTS `breweries` (
  `id` int(11) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `location` varchar(255) DEFAULT NULL,
  `link` varchar(255) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `breweries`
--

INSERT INTO `breweries` (`id`, `name`, `location`, `link`) VALUES
(1, 'Widmer Brothers Brewing', '929 N Russell St, Portland, OR 97227', 'www.widmerbrothers.com/'),
(2, 'Rogue Ales & Spirits', '1339 NW Flanders St, Portland, OR 97209', 'www.rogue.com/'),
(3, 'Fort George Brewery', '1483 Duane St, Astoria, OR 97103', 'www.fortgeorgebrewery.com/'),
(4, 'Crux Fermentation Project', '50 SW Division St, Bend, OR 97702', 'www.cruxfermentation.com/'),
(5, '10 Barrel Brewing', '1411 NW Flanders St, Portland, OR 97232', 'www.10barrel.com/\r\n'),
(6, 'Boneyard Brewery', '37 NW Lake Pl # B, Bend, OR 97701', 'boneyardbeer.com/');

-- --------------------------------------------------------

--
-- Table structure for table `brews`
--

CREATE TABLE IF NOT EXISTS `brews` (
  `beer_id` int(11) NOT NULL,
  `drunk_id` int(11) NOT NULL,
  `id` int(11) NOT NULL,
  `pub_id` int(11) DEFAULT NULL,
  `beer_rating` decimal(3,1) DEFAULT NULL,
  `brew_date` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `drunks`
--

CREATE TABLE IF NOT EXISTS `drunks` (
  `id` bigint(20) unsigned NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `date_of_birth` date DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `location` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `on_tap`
--

CREATE TABLE IF NOT EXISTS `on_tap` (
  `id` int(11) NOT NULL,
  `pub_id` int(11) DEFAULT NULL,
  `beer_id` int(11) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `pubs`
--

CREATE TABLE IF NOT EXISTS `pubs` (
  `id` int(11) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `location` varchar(255) DEFAULT NULL,
  `link` varchar(255) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `beers`
--
ALTER TABLE `beers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `breweries`
--
ALTER TABLE `breweries`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `brews`
--
ALTER TABLE `brews`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `drunks`
--
ALTER TABLE `drunks`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `on_tap`
--
ALTER TABLE `on_tap`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pubs`
--
ALTER TABLE `pubs`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `beers`
--
ALTER TABLE `beers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=45;
--
-- AUTO_INCREMENT for table `breweries`
--
ALTER TABLE `breweries`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `brews`
--
ALTER TABLE `brews`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `drunks`
--
ALTER TABLE `drunks`
  MODIFY `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `on_tap`
--
ALTER TABLE `on_tap`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `pubs`
--
ALTER TABLE `pubs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=9;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
